package com.example.veterinariasnowballnoodles;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

public class DialogoCrearCuenta extends DialogFragment {

    private EditText editTextCorreo, editTextPass;
    private Button botonCrearCuenta;
    private FirebaseAuth mAuth;
    private static final String TAG = "DialogoCrearCuenta";

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        View view = LayoutInflater.from(getActivity()).inflate(R.layout.fragment_dialogo_crear_cuenta, null);

        editTextCorreo = view.findViewById(R.id.edittext_correo);
        editTextPass = view.findViewById(R.id.edittext_pass);
        botonCrearCuenta = view.findViewById(R.id.boton_crear_cuenta);
        mAuth = FirebaseAuth.getInstance();

        botonCrearCuenta.setOnClickListener(v -> {
            String correo = editTextCorreo.getText().toString().trim();
            String pass = editTextPass.getText().toString().trim();

            if (pass.isEmpty()) {
                Toast.makeText(getContext(), "Escriba la contraseña", Toast.LENGTH_LONG).show();
                return;
            }

            if (correo.isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(correo).matches()) {
                Toast.makeText(getContext(), "Formato de correo incorrecto", Toast.LENGTH_LONG).show();
                return;
            }

            crearCuentaFirebase(correo, pass);
        });

        Dialog dialog = new Dialog(getActivity());
        dialog.setContentView(view);
        dialog.setTitle("Crear cuenta");
        return dialog;
    }

    private void crearCuentaFirebase(String correo, String pass) {
        mAuth.createUserWithEmailAndPassword(correo, pass)
                .addOnCompleteListener(requireActivity(), new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Log.d(TAG, "createUserWithEmail:success");
                            FirebaseUser user = mAuth.getCurrentUser();

                            Intent intent = new Intent(getContext(), PrincipalActivity.class);
                            intent.putExtra("Correo", user != null ? user.getEmail() : correo);
                            intent.putExtra("Proveedor", "Usuario/contraseña");
                            startActivity(intent);

                            Toast.makeText(getContext(), "Cuenta creada correctamente", Toast.LENGTH_LONG).show();
                            dismiss();
                        } else {
                            Log.w(TAG, "createUserWithEmail:failure", task.getException());
                            Toast.makeText(getContext(), "Error: " + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                        }
                    }
                });
    }
}
