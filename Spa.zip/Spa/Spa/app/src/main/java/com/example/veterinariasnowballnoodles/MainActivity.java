package com.example.veterinariasnowballnoodles;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Button;
import android.widget.ProgressBar;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button btnLogin, btnRegister;
    ProgressBar progressBar;
    int progressStatus = 0;
    Handler handler = new Handler(); // Permite actualizar UI desde otro hilo

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnLogin = findViewById(R.id.btnLogin);
        btnRegister = findViewById(R.id.btnRegistrar);
        progressBar = findViewById(R.id.progressBar); // Asegúrate que esté en el XML

        // Botón de login manual (lo conservamos intacto)
        btnLogin.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            startActivity(intent);
        });

        // Iniciar barra de carga automática
        new Thread(() -> {
            while (progressStatus < 100) {
                progressStatus += 1;
                handler.post(() -> progressBar.setProgress(progressStatus));
                try {
                    Thread.sleep(30); // Velocidad del progreso
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

            // Al finalizar, ir al login automáticamente
            handler.post(() -> {
                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
            });
        }).start();
    }
}
