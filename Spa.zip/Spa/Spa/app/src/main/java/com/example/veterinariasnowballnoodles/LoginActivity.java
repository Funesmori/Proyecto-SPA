package com.example.veterinariasnowballnoodles;

import android.content.Intent;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.FacebookAuthProvider;
import com.google.firebase.auth.GoogleAuthProvider;

import java.util.Arrays;
import java.util.Locale;

public class LoginActivity extends AppCompatActivity {

    private EditText correoEditText, passEditText;
    private Button botonLogin, boton_crear_cuenta, botonLoginGoogle, botonAccesibilidad, botonFiltroDaltonismo;
    private FirebaseAuth mAuth;
    private CallbackManager callbackManager;
    private GoogleSignInClient mGoogleSignInClient;
    private static final int RC_SIGN_IN = 9001;

    private TextToSpeech tts;
    private boolean filtroAplicado = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Text to Speech
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                tts.setLanguage(new Locale("es", "ES"));
            }
        });

        // Firebase
        mAuth = FirebaseAuth.getInstance();

        // Vistas
        correoEditText = findViewById(R.id.etCorreo);
        passEditText = findViewById(R.id.etContrasena);
        botonLogin = findViewById(R.id.btnIniciarSesion);
        boton_crear_cuenta = findViewById(R.id.boton_crear_cuenta);
        botonLoginGoogle = findViewById(R.id.poten_login_google);
        botonAccesibilidad = findViewById(R.id.boton_accesibilidad);
        botonFiltroDaltonismo = findViewById(R.id.boton_filtro_daltonismo);

        // Google Sign-In
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.web_client))
                .requestEmail()
                .build();
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);

        // Facebook
        callbackManager = CallbackManager.Factory.create();

        // Accesibilidad
        botonAccesibilidad.setOnClickListener(v -> speak("Bienvenido. Por favor, inicia sesión o crea una cuenta."));

        // Filtro daltonismo
        botonFiltroDaltonismo.setOnClickListener(v -> {
            if (!filtroAplicado) {
                aplicarFiltroDaltonismo();
                filtroAplicado = true;
                speak("Filtro de daltonismo activado.");
            } else {
                quitarFiltroDaltonismo();
                filtroAplicado = false;
                speak("Filtro de daltonismo desactivado.");
            }
        });

        // Botón login
        botonLogin.setOnClickListener(v -> {
            String correo = correoEditText.getText().toString().trim();
            String pass = passEditText.getText().toString().trim();

            if (pass.isEmpty()) {
                Toast.makeText(this, "Escribe la contraseña", Toast.LENGTH_LONG).show();
                speak("Por favor, escribe la contraseña.");
                return;
            }

            if (correo.isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(correo).matches()) {
                Toast.makeText(this, "Formato de correo incorrecto.", Toast.LENGTH_LONG).show();
                speak("El correo electrónico no tiene un formato válido.");
                return;
            }

            loginFirebase(correo, pass);
        });

        // Crear cuenta
        boton_crear_cuenta.setOnClickListener(v -> {
            DialogoCrearCuenta dialogo = new DialogoCrearCuenta();
            dialogo.show(getSupportFragmentManager(), null);
        });

        // Login con Google
        botonLoginGoogle.setOnClickListener(v -> loginWithGoogle());

        // Facebook Login
        LoginButton botonLoginFacebook = findViewById(R.id.boton_login_facebook);
        botonLoginFacebook.setOnClickListener(v -> loginWithFacebook());
    }

    private void speak(String text) {
        if (tts != null) {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, null);
        }
    }

    private void aplicarFiltroDaltonismo() {
        View rootView = getWindow().getDecorView().getRootView();
        ColorMatrix colorMatrix = new ColorMatrix(new float[]{
                0.567f, 0.433f, 0f,     0f, 0f,
                0.558f, 0.442f, 0f,     0f, 0f,
                0f,     0.242f, 0.758f, 0f, 0f,
                0f,     0f,     0f,     1f, 0f
        });
        ColorMatrixColorFilter filter = new ColorMatrixColorFilter(colorMatrix);
        rootView.getBackground().setColorFilter(filter);
    }

    private void quitarFiltroDaltonismo() {
        View rootView = getWindow().getDecorView().getRootView();
        if (rootView.getBackground() != null) {
            rootView.getBackground().clearColorFilter();
        }
    }

    private void loginFirebase(String correo, String pass) {
        mAuth.signInWithEmailAndPassword(correo, pass)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        FirebaseUser user = task.getResult().getUser();
                        abrirPrincipal(user.getEmail(), "Usuario/contraseña");
                    } else {
                        Toast.makeText(this, "Usuario o contraseña incorrecto(s)", Toast.LENGTH_LONG).show();
                        speak("Usuario o contraseña incorrectos.");
                    }
                });
    }

    private void loginWithGoogle() {
        Intent signInIntent = mGoogleSignInClient.getSignInIntent();
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }

    private void loginWithFacebook() {
        LoginManager.getInstance().logInWithReadPermissions(this, Arrays.asList("email"));
        LoginManager.getInstance().registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {
                handleFacebookAccessToken(loginResult.getAccessToken());
            }

            @Override
            public void onCancel() {
                speak("Inicio de sesión con Facebook cancelado.");
            }

            @Override
            public void onError(FacebookException error) {
                Toast.makeText(getApplicationContext(), "Error al iniciar sesión con Facebook", Toast.LENGTH_LONG).show();
                speak("Hubo un error al iniciar sesión con Facebook.");
            }
        });
    }

    private void handleFacebookAccessToken(AccessToken token) {
        FirebaseAuth.getInstance()
                .signInWithCredential(FacebookAuthProvider.getCredential(token.getToken()))
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        FirebaseUser user = task.getResult().getUser();
                        abrirPrincipal(user.getEmail(), "Facebook");
                    } else {
                        Toast.makeText(getApplicationContext(), "Error en la autenticación con Firebase", Toast.LENGTH_LONG).show();
                        speak("No se pudo autenticar con Facebook.");
                    }
                });
    }

    private void abrirPrincipal(String correo, String proveedor) {
        Intent intent = new Intent(getApplicationContext(), PrincipalActivity.class);
        intent.putExtra("Correo", correo);
        intent.putExtra("Proveedor", proveedor);
        startActivity(intent);
        finish();
    }

    // 🔧 MANEJO CORRECTO DE GOOGLE SIGN-IN
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == RC_SIGN_IN) {
            try {
                GoogleSignInAccount account = GoogleSignIn.getSignedInAccountFromIntent(data)
                        .getResult(ApiException.class);
                handleSignInResult(account);
            } catch (ApiException e) {
                Log.w("TAG", "Google sign-in failed", e);
                Toast.makeText(this, "Error al iniciar sesión con Google", Toast.LENGTH_LONG).show();
                speak("Falló el inicio de sesión con Google.");
            }
        }

        callbackManager.onActivityResult(requestCode, resultCode, data);
    }

    private void handleSignInResult(GoogleSignInAccount account) {
        if (account != null) {
            FirebaseAuth.getInstance()
                    .signInWithCredential(GoogleAuthProvider.getCredential(account.getIdToken(), null))
                    .addOnCompleteListener(this, task -> {
                        if (task.isSuccessful()) {
                            FirebaseUser user = task.getResult().getUser();
                            speak("Inicio de sesión exitoso. Bienvenido.");
                            abrirPrincipal(user.getEmail(), "Google");
                        } else {
                            Toast.makeText(this, "Error en la autenticación con Firebase", Toast.LENGTH_LONG).show();
                            speak("No se pudo autenticar con Google.");
                        }
                    });
        }
    }

    @Override
    protected void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }
}



